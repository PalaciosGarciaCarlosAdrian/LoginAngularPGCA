import { Component } from '@angular/core';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  model: any = {};
  error: string | null = null;

  constructor() { }

  onSubmit() {
    if (!this.model.username || !this.model.password) {
      this.error = "Todos los campos son requeridos!";
      return;
    }
    this.error = null;
    console.log('User:', this.model);
  }
}